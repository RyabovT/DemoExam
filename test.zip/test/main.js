import abi from "./abi.js";

let web3, ContractInstance,Address, currAcc;
let h1 = document.querySelector('.currAcc')

Address = "0x4265023414D906b3fc69F0CF9bC4d701F778e56a"

async function network() {
    web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"))
    ContractInstance = new web3.eth.Contract(abi,Address)    
    console.log(web3);
    console.log(ContractInstance);
    console.log("Вы подключились");
    let array = await web3.eth.getAccounts()
    let curr = array[0]
    h1.textContent = curr
    h1.value = curr
    render()
}
network()

async function selectAccs() {
    let select = document.querySelector(".selectAcc")
    let arrAccs = await web3.eth.getAccounts()
    for(let i = 0; i < arrAccs.length;i++){
        let option = document.createElement('option')
        option.textContent = arrAccs[i]
        option.value = arrAccs[i]
        select.append(option)
    }
    select.addEventListener("change", function () {
        h1.textContent = select.value
        render()
    })
}
selectAccs()

async function render() {
    let client = await ContractInstance.methods.clients(h1.textContent).call()
    let personal = await ContractInstance.methods.showPersonals().call()
    let request = await ContractInstance.methods.showRequest().call()
    console.log(request);
    console.log(personal);
    let Registration = document.querySelector('.Registration')
    let addReq = document.querySelector('.addReq')
    let editReq = document.querySelector('.editReq')
    let completeReq = document.querySelector('.completeReq')
    if(client.addressClient == "0x0000000000000000000000000000000000000000"){
        Registration.style.display = "block"
        addReq.style.display = "none"
        editReq.style.display = "none"
        completeReq.style.display = "none"
    }
    else{
        Registration.style.display = "none"
        addReq.style.display = "block"
        editReq.style.display = "none"
        completeReq.style.display = "none"
    }
    for(let i = 0; i < personal.length;i++){
        if(h1.textContent == personal[i].addressPersonal){
            if(personal.pos == 0){
                Registration.style.display = "none"
                addReq.style.display = "none"
                editReq.style.display = "none"
                completeReq.style.display = "block"  
            }
            else{
                Registration.style.display = "none"
                addReq.style.display = "none"
                editReq.style.display = "block"
                completeReq.style.display = "block"  
            }
        }
    }
}   
render()

async function Registration() {
    let login = document.querySelector('.loginReg')
    let btnReg = document.querySelector('.btnReg')
    btnReg.addEventListener('click', async function () {
        let reg = await ContractInstance.methods.Registration(login.value).send({from: h1.textContent, gas: 200000, gasPrice: 20000000})
        console.log(reg);
        alert("Вы зарегистрировались!")
        render()
    })
    
}
Registration()

async function addRequest() {
    let detailAddReq = document.querySelector('.detailAddReq')
    let typeAddReq = document.querySelector('.typeAddReq')
    let descAddReq = document.querySelector('.descAddReq')
    let btnAddReq = document.querySelector('.btnAddReq')
    btnAddReq.addEventListener("click", async function () {
        let addReq = await ContractInstance.methods.addRequest(detailAddReq.value,typeAddReq.value,descAddReq.value).send({from: h1.textContent, gas: 200000, gasPrice: 20000000})
        console.log(addReq);
        alert("Вы подали заявку")
    })
}
addRequest()

async function updateRequest() {
    let IdEditReq = document.querySelector('.IdEditReq')
    let btneditReq = document.querySelector('.btneditReq')
    btneditReq.addEventListener("click", async function () {
        let editReq = await ContractInstance.methods.updateRequest(IdEditReq.value-1).send({from: h1.textContent, gas: 200000, gasPrice: 20000000})
        console.log(editReq);
        alert("Вы обновили заявку")
    })
}
updateRequest()

async function completeRequest() {
    let IdcompleteReq = document.querySelector('.IdcompleteReq')
    let btncompleteReq = document.querySelector('.btncompleteReq')
    btncompleteReq.addEventListener("click", async function () {
        let completeReq = await ContractInstance.methods.completeRequest(IdcompleteReq.value-1).send({from: h1.textContent, gas: 200000, gasPrice: 20000000})
        console.log(completeReq);
        alert("Вы завершили заявку")
    })
}
completeRequest()